import java.util.*;
import java.io.*;

public class Exp1118860608 {
  
  public static void main(String[] args) throws Exception {
    int sucursal;
     BufferedReader teclado=new BufferedReader(new InputStreamReader(System.in));
 System.out.println("Elija un Supermercado (1 o  2)");
 int eleccion=Integer.parseInt(teclado.readLine());
            
  }
}
