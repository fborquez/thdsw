/**
 * Auto Generated Java Class.
 */
import java.io.*;
import java.util.*;
import java.text.NumberFormat;

public class Catalogo {
  
  private int codigo;
  private String nombreCat;
  
  public Catalogo(String nombreCat) { 
    /* YOUR CONSTRUCTOR CODE HERE*/
  this.codigo = codigo;
  this.nombreCat = nombreCat;
  }
  
  public String getNombre(){
    return this.nombreCat;    
  }
  /* ADD YOUR CODE HERE */  
}
