import java.util.*;

public class Carro {
  //propiedades, atributos o variables miembro
  
  String nombre;
  int numerodecarro=0;
  Producto producto;
static int totalfactura=0;
  
 public void addProducto(int codigointerno,int preciounitario,String descripcion){
   this.producto=new Producto();
 }
  
   public void ingresarProducto (){
    
      Scanner teclado = new Scanner(System.in);
      
      
      Producto prodasignado=new Producto();
this.totalfactura=this.totalfactura+producto.sumar;
        
        //Asignar un Producto Existente a este Carro
       // this.add(producto);

        
        
            this.addProducto(producto.codigointerno,producto.preciounitario,producto.descripcion);                   



  }
 
  
  
  
  
  
  
  
  
  
}